ZYRA — Version 4 (prototype interactif)

Nouveautés visuelles :
- Apparition progressive des sections et cartes au défilement
- Effets subtils sur les boutons et clics
- Effet de profondeur sur le visuel principal sur ordinateur
- Lumière d'ambiance qui suit le pointeur sur ordinateur
- Navigation et tableaux de bord avec transitions
- Respect du réglage système de réduction des animations

Les fonctions de démonstration de la version 3 sont conservées.
Les comptes, profils, campagnes et candidatures restent enregistrés localement dans le navigateur.
Ce prototype n'a pas encore de serveur, de base de données partagée, d'authentification sécurisée ni d'hébergement public.
Ne pas utiliser de vrais mots de passe ni des données sensibles.

Pour tester : ouvrir index.html dans un navigateur récent.
